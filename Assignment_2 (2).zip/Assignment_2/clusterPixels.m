% Given an image and k or the number of clusters, this function gives back
% an h by w matrix of integers indicating the cluster membership from 1 to
% k for each pixel. 
function labelIm = clusterPixels(Im, k)

% Basic initialization stuff where setting rows and columns and such as 
% well as making image a double one for calculation purposes and getting
% the red, green, and blue channels. 
[numRow,numCol, p] = size(Im);
doubleImage = double(Im);
redChannel = doubleImage(:,:,1);
greenChannel = doubleImage(:,:,2);
blueChannel = doubleImage(:,:,3);
        
redVector = (redChannel(:)-min(redChannel(:))+1);
greenVector = (greenChannel(:)-min(greenChannel(:))+1);
blueVector = (blueChannel(:)-min(blueChannel(:))+1);
        
redVector = repmat(redVector,[1,k]);
greenVector = repmat(greenVector,[1,k]);
blueVector = repmat(blueVector,[1,k]);
        
redMean=(1:k).*max((redVector(:)))/(k+1);
greenMean=(1:k).*max((greenVector(:)))/(k+1);
blueMean=(1:k).*max((blueVector(:)))/(k+1);
        
        
num = length(redVector); 
numIterations = 1000;
% Basically just running the k means algorithm 
% Then at end we get the h by w matrix showing cluster memberships from 1
% to k.
for count=1:numIterations 
    meanRed = repmat(redMean,[num,1]);
    meanGreen = repmat(greenMean,[num,1]);
    meanBlue = repmat(blueMean,[num,1]);
            
    redDistance =(((redVector-meanRed)).^2);
    greenDistance=(((greenVector-meanGreen)).^2);
    blueDistance=(((blueVector-meanBlue)).^2);
    distance = sqrt(redDistance + greenDistance + blueDistance);
            
    [~,label_vector] = min(distance,[],2);
            
    for i=1:k
        index=(label_vector==i);
        redMean(:,i)=ceil(mean(redVector(index)));
        greenMean(:,i)=ceil(mean(greenVector(index)));
        blueMean(:,i)=ceil(mean(blueVector(index)));
    end
end
    labelIm = reshape(label_vector,[numRow, numCol]);
end