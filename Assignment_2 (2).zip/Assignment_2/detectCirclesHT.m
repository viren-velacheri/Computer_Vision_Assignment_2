% This is the Hough Transform function. Done in a little different way
% I couldn't get it to work through looping through the edges like that
% Instead did it this way through a more standard kind of way as will be 
% explained below and even in my writeup. The parameters are the image,
% radius and the threshold for circle to be considered a candidate. Output
% are the calculated centers of these candidate circles. 
function centers = detectCirclesHT(im, radius, threshold)
grayImage = rgb2gray(im);
edgeImage = edge(grayImage,'canny');
[yIndex, xIndex] = find(edgeImage); % get x,y edge pixels
accumulator = zeros(size(edgeImage)); % initializes the accumulator
numRow = size(edgeImage,1); % number of rows in the binary image
numCol = size(edgeImage,2); % number of columns in the binary image

% These for loops are used for fill our accumulator array
% Basically start by getting x pixel and then set bounds if it is below
% 1 or greater than the number of columns, which would mean circle would
% be going outside image space. That is why that check is done.
for count=1:length(xIndex)
    low=xIndex(count) - radius;
    high=xIndex(count)+ radius;
    
    if low < 1 
        low = 1; 
    end
    
    if high > numCol
        high = numCol; 
    end
    
% Loop through from calculated bounds, going 1 at a time and this sets
% up how big our vote space quantization or bin size is so to speak.
% Basically the yChange determines the other possible coordinate that 
% y pixel could be to be considered center of circle. Because two 
% possibilities, we calculate for both and then increment that according
% spot in accumulator array. 
    for x = low:2:high
        yChange = sqrt(radius^2 -(xIndex(count) - x)^2);
        y1 = round(yIndex(count) - yChange);
        y2 = round(yIndex(count) + yChange);
        
% Similar to x, bounds checking is done for both of the possible
% y coordinates
        if y1 < numRow && y1 >= 1
            accumulator(y1,x) = accumulator(y1,x)+1;
        end
        
        if y2 < numRow && y2 >= 1
            accumulator(y2,x) = accumulator(y2,x)+1;
        end
    end
end

% Use this function imregionalmax to final the local maxima and is the
% attempt at non maximum suppression. Even though we do use canny edge 
% detection, this is done just to be on the safe side.
accumulatorbinaryMax = imregionalmax(accumulator);
[potentialY, potentialX] = find(accumulatorbinaryMax == 1);
tempCenters = [];
% Simple for loop where for any point that exceeds threshold, add that 
% as center to our tempCenters array which is set to our result centers
% once we exit for loop. 
for count = 1:length(potentialY)
    if accumulator(potentialY(count),potentialX(count)) >= threshold
        tempCenters = [potentialX(count) potentialY(count); tempCenters];
    end
end

% These are the centers that we got.
centers = tempCenters;
end