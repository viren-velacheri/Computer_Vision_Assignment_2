function accumulatorArray = getAccumulator(I, radius)
[index1, index2] = find(I);
[width, height] = size(I);
nrWidth = width + 2 * radius;
nrHeight = height + 2 * radius;
accumulatorArray = zeros(nrWidth * nrHeight, 1, 'uint32');
[tR, tC] = circlepoints1(radius);
tempR = tR;
tempC = tC;
tempRad = [repmat(1, 1, length(tR))];
tempInd = uint32( tempR+radius + nrWidth*(tempC + radius) + nrWidth*nrHeight*(tempRad-1) );
featInd = uint32( index1' + nrWidth*(index2-1)' );

% Loop over features
for f = featInd
    % shift template to be centred on this feature
    incI = tempInd + f;
    % and update the accumulator
    accumulatorArray(incI) = accumulatorArray(incI) + 1;
end

accumulatorArray = reshape(double(accumulatorArray), nrWidth, nrHeight, 1);
end





