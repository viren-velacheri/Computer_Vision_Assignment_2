% This is the RANSAC function. Inputs are the edge itself, the
% threshold inlier count, the threshold distance, and the number of 
% iterations. The output is centers for centers that passed threshold mark.
function [centers] = detectCirclesRANSAC(im, radius, thresholdInlierCount, thresholdDistance, numIterations)
grayImage = rgb2gray(im);
edgeImage = edge(grayImage,'canny');
[yIndex, xIndex] = find(edgeImage); % find x,y of edge pixels
numRow = size(edgeImage,1); % number of rows in the edge image
numCol = size(edgeImage,2); % number of columns in the edge image
centersTemp = [];
bestScore = 0;
indices = [];
bestScores = [];
% A simple for loop that for each iteration gets two random edge points, 
% calculates the possible center coordinates, and then in next for loop
% sees how many edge points are in range of these centers. If they are,
% the respective scores are incremented. After that, if the circle meets 
% the threshold score, it is added as a candidate centersTemp which will 
% be set to the returned centers variable.
for i=1:numIterations
randomIndices = randsample(length(xIndex), 2, false);
x1 = xIndex(randomIndices(1));
y1 = yIndex(randomIndices(1));
x2 = xIndex(randomIndices(2));
y2 = yIndex(randomIndices(2));
radiusSquared = radius ^ 2;
% Basically the calculations done to get both possible centers of circles
% given two random edge points. 
q = sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)));
x3 = (x1 + x2) / 2;
centerx = x3 + sqrt(abs(radiusSquared - ((q / 2) * (q / 2)))) * ((y1 - y2) / q);
y3 = (y1 + y2) / 2;
centery = y3 + sqrt(abs(radiusSquared - ((q / 2) * (q / 2)))) * ((x2 - x1) / q);

centerx2 = x3 - sqrt(abs(radiusSquared - ((q / 2) * (q / 2)))) * ((y1 - y2) / q);
centery2 = y3 - sqrt(abs(radiusSquared - ((q / 2) * (q / 2)))) * ((x2 - x1) / q);
score = 0;
score2 = 0;
for j=1:numRow
for k=1:numCol
% Just checking and going through edge points.
    if edgeImage(j, k) == 1   
        distance = sqrt((centerx - k)^2 + (centery - j)^2) - radius;
        distance2 = sqrt((centerx2 - k)^2 + (centery2 - j)^2) - radius;
        if distance >= 0 && distance <= thresholdDistance
            score = score + 1;
        end
        if distance2 >= 0 && distance2 <= thresholdDistance
            score2 = score2 + 1;
        end
    end
end
end 
if score >= thresholdInlierCount
    center = [round(centerx) round(centery)];
    centersTemp = [centersTemp; center];
end

if score2 >= thresholdInlierCount
    center = [round(centerx2) round(centery2)];
    centersTemp = [centersTemp; center];
end

% These are done below for the plotting of number of tries against 
% the best score.
if score > bestScore
    bestScore = score;
end

if score2 > bestScore
    bestScore = score2;
end
    
indices = [indices; i];
bestScores = [bestScores; bestScore];

end
% plot(indices, bestScores);
% title("How Best Score changes over Tries");
% xlabel("Number of Tries");
% ylabel("Best Score");

centers = centersTemp;
end



