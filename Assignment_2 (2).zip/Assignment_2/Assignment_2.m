% Assignment 2
% Name: Viren Velacheri, EID: vv6898
% Slip days: 10

% This first section is regarding the coins image. Hough transform and
% RANSAC are done and the radius we use is 40.
coinsPicture = 'coins.jpg';
planetsPicture = 'planets.jpg';
mmsPicture = 'mms.jpg';
figure("name", "Coins Circle Detection with Radius 40","NumberTitle", "off");
coinsImage = imread(coinsPicture);
radius = 40;
% Using inliers threshold of 65
centers = detectCirclesHT(coinsImage, radius, 65);
% Do the below so able to show detected circles on image.
rows = size(centers, 1);
radii = radius*ones(rows,1);
subplot(1,2,1);
imshow(coinsImage);
title("Hough Transform");
viscircles(centers, radii);

% Using inliers threshold of 85, threshold distance is set to 1
% and number of iterations we run is 10000.
centers = detectCirclesRANSAC(coinsImage, radius, 85, 1, 10000);
% Do the below so able to show detected circles on image.
rows = size(centers, 1);
radii = radius*ones(rows,1);
subplot(1,2,2);
imshow(coinsImage);
title("RANSAC");
viscircles(centers, radii);

% This section of image analysis is regarding the planets image. Hough 
% Transform and RANSAC are done and radius we use is 100 or basically
% locating the big planet in picture.
figure("name", "Planets Circle Detection with Radius 100","NumberTitle", "off");
planetsImage = imread(planetsPicture);
radius = 100;
% Using an inlier threshold of 110
centers = detectCirclesHT(planetsImage, radius, 110);
% Do below to show detected circle in image.
rows = size(centers, 1);
radii = radius*ones(rows,1);
subplot(1,2,1);
imshow(planetsImage);
title("Hough Transform");
viscircles(centers, radii);

% Using an inlier threshold of 145, threshold distance is 1, and number
% of iterations we run is 10000
centers = detectCirclesRANSAC(planetsImage, radius, 145, 1, 10000);
% do below to show detected circle in image.
rows = size(centers, 1);
radii = radius*ones(rows,1);
subplot(1,2,2);
imshow(planetsImage);
title("RANSAC");
viscircles(centers, radii);

% This section of image analysis is regarding the m&m's image. Hough 
% Transform and RANSAC are done and the radius we use is 20.
figure("name", "MMs Circle Detection with Radius 20","NumberTitle", "off");
mmsImage = imread(mmsPicture);
radius = 20;
% Inliers threshold is 35.
centers = detectCirclesHT(mmsImage, radius, 35);
% do below to show detected circles in image.
rows = size(centers, 1);
radii = radius*ones(rows,1);
subplot(1,2,1);
imshow(mmsImage);
title("Hough Transform");
viscircles(centers, radii);

% Inliers threshold is 42, threshold distance is 1, and the number of 
% iterations done is 10000
centers = detectCirclesRANSAC(mmsImage, radius, 42 , 1, 10000);
% do below to show detected circles in image.
rows = size(centers, 1);
radii = radius*ones(rows,1);
subplot(1,2,2);
imshow(mmsImage);
title("RANSAC");
viscircles(centers, radii);

% This section is regarding Gumball image where kmeans and cluster
% boundary results are displayed for the image. For this and all the other
% following images, the k used was 3 since that seemed to be the common
% one to use.
figure("name", "GumBall Image Analysis Results","NumberTitle", "off");
gumballsPicture = 'gumballs.jpg';
gumballsImage = imread(gumballsPicture);
kMeansResult = clusterPixels(gumballsImage, 3);
boundaryResult = boundaryPixels(kMeansResult);
subplot(1, 2, 1);
imshow(label2rgb(kMeansResult));
title("K Means Result for Gumballs with 3 Clusters");
subplot(1, 2, 2);
imshow(boundaryResult);
title("Cluster Boundary Result for Gumballs");

% This section is regarding Snake image where kmeans and cluster
% boundary results are displayed for the image. For this and all the other
% following images, the k used was 3 since that seemed to be the common
% one to use.
figure("name", "Snake Image Analysis Results","NumberTitle", "off");
snakePicture = 'snake.jpg';
snakeImage = imread(snakePicture);
kMeansResult = clusterPixels(snakeImage, 3);
boundaryResult = boundaryPixels(kMeansResult);
subplot(1, 2, 1);
imshow(label2rgb(kMeansResult));
title("K Means Result for Snake with 3 Clusters");
subplot(1, 2, 2);
imshow(boundaryResult);
title("Cluster Boundary Result for Snake");

% This section is regarding Twins image where kmeans and cluster
% boundary results are displayed for the image. For this and all the other
% following images, the k used was 3 since that seemed to be the common
% one to use.
figure("name", "Twins Image Analysis Results","NumberTitle", "off");
twinsPicture = 'twins.jpg';
twinsImage = imread(twinsPicture);
kMeansResult = clusterPixels(twinsImage, 3);
boundaryResult = boundaryPixels(kMeansResult);
subplot(1, 2, 1);
imshow(label2rgb(kMeansResult));
title("K Means Result for Twins with 3 Clusters");
subplot(1, 2, 2);
imshow(boundaryResult);
title("Cluster Boundary Result for Twins");

% This section is regarding Family image where kmeans and cluster
% boundary results are displayed for the image. For this and all the other
% following images, the k used was 3 since that seemed to be the common
% one to use.
figure("name", "Family Image Analysis Results","NumberTitle", "off");
familyPicture = 'family.jpeg';
familyImage = imread(familyPicture);
kMeansResult = clusterPixels(familyImage, 3);
boundaryResult = boundaryPixels(kMeansResult);
subplot(1, 2, 1);
imshow(label2rgb(kMeansResult));
title("K Means Result for Family with 3 Clusters");
subplot(1, 2, 2);
imshow(boundaryResult);
title("Cluster Boundary Result for Family");













