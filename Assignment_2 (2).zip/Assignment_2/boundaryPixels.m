% The cluster boundary pixel results. Takes in result from cluster pixels
% function and essentially gives back in black and white image of it.
function boundaryIm = boundaryPixels(labelIm)
% Set up boundary matrix.
% Get number of rows and columns
imSize = size(labelIm);
boundaryIm = zeros(imSize(1), imSize(2));
[numRows, numCols] = size(boundaryIm);

% Just basic for loop where pixel values are set to 1 for those that
% are not near boundary and aren't equal to the current pixel it is on. 
% This is essentially how this label matrix is filled with just 1s and 
% 0s and the cluster boundaries are calculated.
for i=1:numRows
    for j=1:numCols
        right = j + 1;
        left = j - 1;
        up = i - 1;
        down = i + 1;
        if (right <= numCols && labelIm(i,j) ~= labelIm(i, right))
            boundaryIm(i,j) = 1;
        end
        if left >= 1 && labelIm(i, j) ~= labelIm(i, left)
            boundaryIm(i, j) = 1;
        end
        if up >= 1 && labelIm(i,j) ~= labelIm(up, j)
            boundaryIm(i, j) = 1;
        end
        if down <= numRows && labelIm(i, j) ~= labelIm(down, j)
            boundaryIm(i, j) = 1;
        end
    end
end
end

